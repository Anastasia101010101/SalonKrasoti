﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SalonKrasoti.ModelEF;

namespace SalonKrasoti
{
    public partial class ClientForm : Form
    {
        static public List<int> lstSelectedIdData = new List<int>();
        public ClientForm()
        {
            InitializeComponent();
        }

        private void ClientForm_Load(object sender, EventArgs e)
        {
            категория_услугиBindingSource.DataSource = Program.db.Категория_услуги.ToList();
            услугиBindingSource.DataSource = Program.db.Услуги.ToList();

        }
    }
}
