﻿using SalonKrasoti.ModelEF;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SalonKrasoti.ModelEF;

namespace SalonKrasoti
{
    public partial class Form1 : Form
    {   
        int сaptcha = 0;
        string сaptchastr = "";
        public Form1()
        {
            
            InitializeComponent();
        }

        private void EnterBtn_Click(object sender, EventArgs e)
        {
            //проверяем, что в текстовые поля введены данные
            if ((LoginTxt.Text == "") || (PswTxt.Text == ""))
            {
                MessageBox.Show("Введите логин и пароль! ");
                return;
            }
            // ищем введённого пользователя
            Пользователи usr = Program.db.Пользователи.SingleOrDefault(m => m.Логин == LoginTxt.Text);
            //проверяем что логин не пустой и пароль верный
            if ((usr != null) && (usr.Пароль == PswTxt.Text))
            {
                // сохраняем соответствующие данные в статических переменных
                Program.USER = usr;
                Program.FORM = this;
                //если видна капча
                if ((CaptchaTxt.Visible == true) && (CaptchaTxt.Text == сaptchastr)) 
                {
                    if (usr.IDРоли == 1)
                    {
                        // создаем форму директора
                        ClientForm frm = new ClientForm();
                        // показываем форму директора
                        frm.Show();
                        // форму подключения скрываем (но не закрываем)
                        this.Hide();
                        return;
                    }
                    // если роль Администратор
                    else if (usr.IDРоли == 2)
                    {
                        // создаем форму менеджера
                        AdminForm frm = new AdminForm();
                        // показываем форму менеджера
                        frm.Show();
                        // начальную форму подключения скрываем (но не закрываем)
                        this.Hide();
                        return;
                    }
                    // если роль Сотрудник
                    else if (usr.IDРоли == 3)
                    {
                        // создаем форму администратора
                        EmployeeForm frm = new EmployeeForm();
                        // показываем форму администратора
                        frm.Show();
                        // начальную форму подключения скрываем (но не закрываем)
                        this.Hide();
                        return;
                    }
                    //если пара логин-пароль верная, а капча нет
                    else
                    {

                        LoginTxt.Text = "";
                        PswTxt.Text = "";
                        MessageBox.Show(" Пример решен не верно");
                        return;

                    }
                }
                if (usr.IDРоли == 1)
                {
                    // создаем форму клиента
                    ClientForm frm = new ClientForm();
                    // показываем форму клиента
                    frm.Show();
                    // форму подключения скрываем (но не закрываем)
                    this.Hide();
                }
                // если роль Администратор
                else if (usr.IDРоли == 2)
                {
                    // создаем форму менеджера
                    AdminForm frm = new AdminForm();
                    // показываем форму менеджера
                    frm.Show();
                    // начальную форму подключения скрываем (но не закрываем)
                    this.Hide();
                }
                // если роль Сотрудник
                else if (usr.IDРоли == 3)
                {
                    // создаем форму администратора
                    EmployeeForm frm = new EmployeeForm();
                    // показываем форму администратора
                    frm.Show();
                    // начальную форму подключения скрываем (но не закрываем)
                    this.Hide();
                }


            }
            else
            {
                // если данные введены неправильно, то показываем сообщение
                MessageBox.Show(" Логин или пароль ведены не верно!");
                //делаем видимыми поля связанные с капчей
                CaptchaTxt.Visible = true;
                //рандомно выводится картинка с капчей 
                Random rand = new Random();
                int a = rand.Next(0, 10);
                int b = rand.Next(0, 10);
                сaptcha = (a + b);
                string сaptchastr = Convert.ToString(сaptcha);
                Captcha.Text = $"{a}+{b}";
                Captcha.Visible = true;
                CaptchaLb.Text = "Решите пример";
                CaptchaLb.Visible = true;
                return;
            }
        }

        private void PswCheck_Click(object sender, EventArgs e)
        {
            //скрываем\показываем пароль
            if (PswCheck.Checked == true)
            {
                PswTxt.UseSystemPasswordChar = false;
            }
            else
            {
                PswTxt.UseSystemPasswordChar = true;
            }
        }

        private void PswCheck_TextChanged(object sender, EventArgs e)
        {

        }

        private void PswTxt_TextChanged(object sender, EventArgs e)
        {
            //скрываем пароль
            PswTxt.UseSystemPasswordChar = true;
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            this.Close();//форма закрывается
        }
    }
}
