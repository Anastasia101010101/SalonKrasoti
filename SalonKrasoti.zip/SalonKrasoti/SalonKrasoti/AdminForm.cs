﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SalonKrasoti.ModelEF;

namespace SalonKrasoti
{
    public partial class AdminForm : Form
    {
        static public List<int> lstSelectedIdData = new List<int>();
        public AdminForm()
        {
            InitializeComponent();
        }

        private void AdminForm_Load(object sender, EventArgs e)
        {
            категорияуслугиBindingSource.DataSource = Program.db.Категория_услуги.ToList();
            услугиBindingSource.DataSource = Program.db.Услуги.ToList();
            предстоящие_записиBindingSource.DataSource = Program.db.Предстоящие_записи.ToList();
            отчетыBindingSource.DataSource = Program.db.Отчеты.ToList();
        }
    }
}
