﻿namespace SalonKrasoti
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Captcha = new System.Windows.Forms.Label();
            this.CaptchaLb = new System.Windows.Forms.Label();
            this.CaptchaTxt = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.PswCheck = new System.Windows.Forms.CheckBox();
            this.PswTxt = new System.Windows.Forms.TextBox();
            this.LoginTxt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ExitBtn = new System.Windows.Forms.Button();
            this.EnterBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Captcha
            // 
            this.Captcha.AutoSize = true;
            this.Captcha.BackColor = System.Drawing.SystemColors.Control;
            this.Captcha.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(137)))), ((int)(((byte)(178)))), ((int)(((byte)(188)))));
            this.Captcha.Location = new System.Drawing.Point(373, 300);
            this.Captcha.Name = "Captcha";
            this.Captcha.Size = new System.Drawing.Size(17, 15);
            this.Captcha.TabIndex = 40;
            this.Captcha.Text = "**";
            this.Captcha.Visible = false;
            // 
            // CaptchaLb
            // 
            this.CaptchaLb.AutoSize = true;
            this.CaptchaLb.Location = new System.Drawing.Point(259, 181);
            this.CaptchaLb.Name = "CaptchaLb";
            this.CaptchaLb.Size = new System.Drawing.Size(33, 15);
            this.CaptchaLb.TabIndex = 39;
            this.CaptchaLb.Text = "label4";
            this.CaptchaLb.Visible = false;
            // 
            // CaptchaTxt
            // 
            this.CaptchaTxt.Location = new System.Drawing.Point(359, 339);
            this.CaptchaTxt.Name = "CaptchaTxt";
            this.CaptchaTxt.Size = new System.Drawing.Size(120, 22);
            this.CaptchaTxt.TabIndex = 38;
            this.CaptchaTxt.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(103, 47);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(116, 99);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 37;
            this.pictureBox1.TabStop = false;
            // 
            // PswCheck
            // 
            this.PswCheck.AutoSize = true;
            this.PswCheck.Location = new System.Drawing.Point(504, 271);
            this.PswCheck.Name = "PswCheck";
            this.PswCheck.Size = new System.Drawing.Size(15, 14);
            this.PswCheck.TabIndex = 36;
            this.PswCheck.UseVisualStyleBackColor = true;
            this.PswCheck.TextChanged += new System.EventHandler(this.PswCheck_TextChanged);
            this.PswCheck.Click += new System.EventHandler(this.PswCheck_Click);
            // 
            // PswTxt
            // 
            this.PswTxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(102)))), ((int)(((byte)(0)))));
            this.PswTxt.Location = new System.Drawing.Point(359, 268);
            this.PswTxt.Name = "PswTxt";
            this.PswTxt.Size = new System.Drawing.Size(117, 22);
            this.PswTxt.TabIndex = 35;
            this.PswTxt.TextChanged += new System.EventHandler(this.PswTxt_TextChanged);
            // 
            // LoginTxt
            // 
            this.LoginTxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(102)))), ((int)(((byte)(0)))));
            this.LoginTxt.Location = new System.Drawing.Point(359, 213);
            this.LoginTxt.Name = "LoginTxt";
            this.LoginTxt.Size = new System.Drawing.Size(117, 22);
            this.LoginTxt.TabIndex = 34;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(137)))), ((int)(((byte)(178)))), ((int)(((byte)(188)))));
            this.label3.Location = new System.Drawing.Point(238, 268);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 15);
            this.label3.TabIndex = 33;
            this.label3.Text = "Пароль";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(137)))), ((int)(((byte)(178)))), ((int)(((byte)(188)))));
            this.label2.Location = new System.Drawing.Point(238, 220);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 15);
            this.label2.TabIndex = 32;
            this.label2.Text = "Логин";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(137)))), ((int)(((byte)(178)))), ((int)(((byte)(188)))));
            this.label1.Location = new System.Drawing.Point(355, 166);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 15);
            this.label1.TabIndex = 31;
            this.label1.Text = "Вход в систему";
            // 
            // ExitBtn
            // 
            this.ExitBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(137)))), ((int)(((byte)(178)))), ((int)(((byte)(188)))));
            this.ExitBtn.ForeColor = System.Drawing.Color.White;
            this.ExitBtn.Location = new System.Drawing.Point(504, 339);
            this.ExitBtn.Name = "ExitBtn";
            this.ExitBtn.Size = new System.Drawing.Size(102, 41);
            this.ExitBtn.TabIndex = 30;
            this.ExitBtn.Text = "Выйти";
            this.ExitBtn.UseVisualStyleBackColor = false;
            // 
            // EnterBtn
            // 
            this.EnterBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(137)))), ((int)(((byte)(178)))), ((int)(((byte)(188)))));
            this.EnterBtn.ForeColor = System.Drawing.Color.White;
            this.EnterBtn.Location = new System.Drawing.Point(216, 339);
            this.EnterBtn.Name = "EnterBtn";
            this.EnterBtn.Size = new System.Drawing.Size(102, 41);
            this.EnterBtn.TabIndex = 29;
            this.EnterBtn.Text = "Войти";
            this.EnterBtn.UseVisualStyleBackColor = false;
            this.EnterBtn.Click += new System.EventHandler(this.EnterBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(933, 519);
            this.Controls.Add(this.Captcha);
            this.Controls.Add(this.CaptchaLb);
            this.Controls.Add(this.CaptchaTxt);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.PswCheck);
            this.Controls.Add(this.PswTxt);
            this.Controls.Add(this.LoginTxt);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ExitBtn);
            this.Controls.Add(this.EnterBtn);
            this.Font = new System.Drawing.Font("Monotype Corsiva", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(137)))), ((int)(((byte)(178)))), ((int)(((byte)(188)))));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Form1";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Text = "Зайка";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Captcha;
        private System.Windows.Forms.Label CaptchaLb;
        private System.Windows.Forms.TextBox CaptchaTxt;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.CheckBox PswCheck;
        private System.Windows.Forms.TextBox PswTxt;
        private System.Windows.Forms.TextBox LoginTxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button ExitBtn;
        private System.Windows.Forms.Button EnterBtn;
    }
}

