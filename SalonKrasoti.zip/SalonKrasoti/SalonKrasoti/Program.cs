﻿using SalonKrasoti.ModelEF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalonKrasoti
{
    internal static class Program
    {
        // статическое открытое поле для хранения подключенного пользователя
        static public Пользователи USER = null;
        static public Form FORM = null;
        // статическое открытое поле для объекта модели
        public static Model1 db = new Model1();
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
